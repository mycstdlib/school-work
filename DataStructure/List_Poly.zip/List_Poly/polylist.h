/*
 * Author: Allen Ng (1310587)
 * Description: A linear list for polynomial.
 * Created on: Mar 11th 2015
 */
#include <cstring>
#include <iostream>

#ifndef _LISTPOLY_H
#define _LISTPOLY_H

//Error code type
enum err_code
{
success = 0,
empty = 1,
overflow = 2,
notfound = 3,
outofrange = 4,
};

typedef int err_t;

//A term of a polynomial (i.e. this represents ax^b)
class Term
{

public:
  int m_iCoefficient;
  int m_iExponent;

public:
  Term *m_pNext;

public:
  Term(int iCoefficient, int iExponent);

  int getCoefficient(){return m_iCoefficient;}
  void setCoefficient(int iCoefficient){m_iCoefficient = iCoefficient;}

  int getExponent(){return m_iExponent;}
  void setExponent(int iExponent){ m_iExponent = iExponent;}

  void Show()
  {
    if(m_iExponent != 0)
      std::cout<<m_iCoefficient<<"x^"<<m_iExponent<<std::endl;
    else
      std::cout<<m_iCoefficient<<std::endl;
  }
};


//The polynomial implemented by linear list.
//The list maintains the property that, at a certain time, there is exactly no two terms have the same exponent
class Polynomial
{
protected:
  Term *m_pHead, *m_pCurr;
  int m_iLength;

public:
  Polynomial();
  err_t insert(int, int);
  err_t retrieve(const int, Term&);
  err_t find(const int, Term&);
  err_t alter(int, int);
  err_t update(int, int, int);
  err_t remove(int, Term&);
  err_t removeExp(int, Term&);
  err_t clear();
  
  err_t add(Polynomial&);
  err_t sub(Polynomial&);
  err_t multi(Polynomial&);
  err_t divide(Polynomial&, Polynomial&);
  err_t diff();
  
  ~Polynomial();
/*
  std::string toString();
  */
  void Display()
  {
    m_pCurr = m_pHead;
    if(m_iLength == 0)
    {
      std::cout<<"0"<<std::endl;
      return;
    }
    while(m_pCurr->m_pNext != 0)
    {
      m_pCurr = m_pCurr->m_pNext;
      m_pCurr->Show();
    }
  }
};

#endif
