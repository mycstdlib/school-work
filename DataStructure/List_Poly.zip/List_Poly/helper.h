#include <iostream>
#include <fstream>
#include "polylist.h"

#ifndef _HELPER_H
#define _HELPER_H

class Helper
{
public:
  void readpoly(std::ifstream& , Polynomial&);
};

#endif
